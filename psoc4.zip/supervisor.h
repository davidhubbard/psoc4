#ifndef _SUPERVISOR_H_
#define _SUPERVISOR_H_

#include <stdbool.h>

typedef void* (*SupervisorRunnableFunc)(void* arg);

bool supervisorRun(SupervisorRunnableFunc fnc, void *param, void **retVal);



#endif
